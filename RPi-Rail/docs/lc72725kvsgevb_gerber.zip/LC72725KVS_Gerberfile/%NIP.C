CDO_Photo_command_file.
set increment   0                       |�@�@�@�@�@�@�@�@�@���W�l: �A�u�\�����[�g
set inch        0                       |�@�@�@�@�@�@�@�@���W�P��: �~�� 
set minif       3                       |�@�@�@�@�@�@�@�@�ŏ��P��: 0.001
set lzspf       1                       |�@�@�@�@�@�@�[���T�v���X: ���[�f�B���O
set keta        8                       |�@�@�@�@�@�@�f�[�^�̌���: 8
set frctn       0                       |�@�@�@�@�@�@�����_�̈ʒu: 0
set plusf       0                       |�@�@�@�@�@�@�@�@�{�}�[�N: �t���Ȃ�
set zrdtf       1                       |�@�@�@�@�@�@�@�@�O�f�[�^: �w�x�̂�
set iniset      "e"                     |�@�@�@�@�@�@�J�n�R�}���h: e
set aptsel      "G54Dae"                |�@�A�p�[�`���I���R�}���h: G54Dae
set flashp      "D02eG01xeD03e"         |�@�@�@�t���b�V���R�}���h: D02eG01xeD03e
set linmov      "D02eG01xe"             |�@�@�@�@�@�@�ړ��R�}���h: D02eG01xe
set lindrw      "D01eG01xe"             |�@�@�@�@�@�@�����R�}���h: D01eG01xe
set crldrw      "D01eG02xie"            |�@�@�@�E����~�ʃR�}���h: D01eG02xie
set ccldrw      "D01eG03xie"            |�@�@�@������~�ʃR�}���h: D01eG03xie
set cir4f       0                       |�@�@�@�@�@�@�@�@�@�@�~��: �S�~ 
set stpset      "zM00er"                |�@�@�@�@�@�@�I���R�}���h: zM00er
set mtlbl       0                       |�@�@�@�@�@�@�@�l�s���x��: �t���Ȃ� 
set outcode     2                       |�@�@�@�@�@�@�@�ϊ��R�[�h: ASCII 
set eobcode     0x2a                    |�@�@�@�@�@�@�R�[�h (Hex):  EOB: 0x2a
set eorcode     0x25                    |                     EOR: 0x25
set spccode     0x20                    |              SPACE(PAD): 0x20
set endset      1                       |�@�@�@�l�s�e�[�v�}�[�N��: ����: 1
set eofset      1                       |                    �I��: 1
set blocklen    512                     |�@�@�@�l�s�u���b�N�@����: 512
set mtpad       1                       |�@�@�@�l�s�u���b�N�p�b�h: �p�b�h����
#  ���̑�         �T�C�Y   D#     �ʐ�
set dcdano[  0]    0.300   41    0.000  |�@�@�@ �@�@0.3mm�̃��C��:
set dcdano[  1]    0.500   45    0.000  |�@�@�@�@�@ 1.0mm�̃��C��:
set dcdano[  2]    0.300   41    0.000  |�@�@�@�@�@�T�[�}�����C��:
set dcdano[  3]    0.000   10    0.000  |�@�@�@�@�@�@�z�[���}�[�N:            
set dcdano[  4]    0.000   37    0.000  |�@�@�@�@�@�`�F�b�N�}�[�N:            
# ���C��          �T�C�Y   D#     �ʐ�
set dcdlin[  0]    8.200  123   52.810
set dcdlin[  1]    8.000  122   50.266
set dcdlin[  2]    7.500  121   44.179
set dcdlin[  3]    7.200  118   40.715
set dcdlin[  4]    7.100  117   39.592
set dcdlin[  5]    7.000  116   38.485
set dcdlin[  6]    6.900  115   37.393
set dcdlin[  7]    6.800  114   36.317
set dcdlin[  8]    6.700  113   35.257
set dcdlin[  9]    6.600  112   34.212
set dcdlin[ 10]    6.500  111   33.183
set dcdlin[ 11]    6.400  110   32.170
set dcdlin[ 12]    6.300  109   31.173
set dcdlin[ 13]    6.200  108   30.191
set dcdlin[ 14]    6.100  107   29.225
set dcdlin[ 15]    6.000  106   28.274
set dcdlin[ 16]    5.900  105   27.340
set dcdlin[ 17]    5.800  104   26.421
set dcdlin[ 18]    5.700  103   25.518
set dcdlin[ 19]    5.600  102   24.630
set dcdlin[ 20]    5.500  101   23.758
set dcdlin[ 21]    5.400  100   22.902
set dcdlin[ 22]    5.300   99   22.062
set dcdlin[ 23]    5.200   98   21.237
set dcdlin[ 24]    5.100   97   20.428
set dcdlin[ 25]    5.000   96   19.635
set dcdlin[ 26]    4.900   95   18.857
set dcdlin[ 27]    4.800   94   18.096
set dcdlin[ 28]    4.700   93   17.349
set dcdlin[ 29]    4.600   92   16.619
set dcdlin[ 30]    4.500   91   15.904
set dcdlin[ 31]    4.400   90   15.205
set dcdlin[ 32]    4.300   89   14.522
set dcdlin[ 33]    4.200   88   13.854
set dcdlin[ 34]    4.100   87   13.203
set dcdlin[ 35]    4.000   86   12.566
set dcdlin[ 36]    3.900   85   11.946
set dcdlin[ 37]    3.800   84   11.341
set dcdlin[ 38]    3.700   83   10.752
set dcdlin[ 39]    3.600   82   10.179
set dcdlin[ 40]    3.500   81    9.621
set dcdlin[ 41]    3.400   80    9.079
set dcdlin[ 42]    3.300   79    8.553
set dcdlin[ 43]    3.200   78    8.043
set dcdlin[ 44]    3.100   77    7.548
set dcdlin[ 45]    3.000   76    7.069
set dcdlin[ 46]    2.900   75    6.605
set dcdlin[ 47]    2.800   74    6.158
set dcdlin[ 48]    2.700   73    5.726
set dcdlin[ 49]    2.600   72    5.309
set dcdlin[ 50]    2.500   71    4.909
set dcdlin[ 51]    2.400   70    4.524
set dcdlin[ 52]    2.300   69    4.155
set dcdlin[ 53]    2.200   68    3.801
set dcdlin[ 54]    2.100   67    3.464
set dcdlin[ 55]    2.000   66    3.142
set dcdlin[ 56]    1.900   65    2.835
set dcdlin[ 57]    1.800   64    2.545
set dcdlin[ 58]    1.700   63    2.270
set dcdlin[ 59]    1.600   62    2.011
set dcdlin[ 60]    1.500   61    1.767
set dcdlin[ 61]    1.450   60    1.651
set dcdlin[ 62]    1.400   59    1.539
set dcdlin[ 63]    1.350   58    1.431
set dcdlin[ 64]    1.300   57    1.327
set dcdlin[ 65]    1.250   56    1.227
set dcdlin[ 66]    1.200   55    1.131
set dcdlin[ 67]    1.100   54    0.950
set dcdlin[ 68]    1.000   53    0.785
set dcdlin[ 69]    0.900   52    0.636
set dcdlin[ 70]    0.800   51    0.503
set dcdlin[ 71]    0.750   50    0.442
set dcdlin[ 72]    0.700   49    0.385
set dcdlin[ 73]    0.650   48    0.332
set dcdlin[ 74]    0.600   47    0.283
set dcdlin[ 75]    0.550   46    0.238
set dcdlin[ 76]    0.500   45    0.196
set dcdlin[ 77]    0.450   44    0.159
set dcdlin[ 78]    0.400   43    0.126
set dcdlin[ 79]    0.350   42    0.096
set dcdlin[ 80]    0.320  124    0.080
set dcdlin[ 81]    0.300   41    0.071
set dcdlin[ 82]    0.250   40    0.049
set dcdlin[ 83]    0.220   39    0.038
set dcdlin[ 84]    0.200   38    0.031
set dcdlin[ 85]    0.180   37    0.025
set dcdlin[ 86]    0.150   36    0.018
set dcdlin[ 87]    0.120  120    0.011
set dcdlin[ 88]    0.100   35    0.008
set dcdlin[ 89]    0.050  119    0.002
# �ۃX���[�z�[��  �T�C�Y   D#     �ʐ�
set dcdrnd[  0]    8.200  123   52.810
set dcdrnd[  1]    8.000  122   50.266
set dcdrnd[  2]    7.500  121   44.179
set dcdrnd[  3]    7.200  118   40.715
set dcdrnd[  4]    7.100  117   39.592
set dcdrnd[  5]    7.000  116   38.485
set dcdrnd[  6]    6.900  115   37.393
set dcdrnd[  7]    6.800  114   36.317
set dcdrnd[  8]    6.700  113   35.257
set dcdrnd[  9]    6.600  112   34.212
set dcdrnd[ 10]    6.500  111   33.183
set dcdrnd[ 11]    6.400  110   32.170
set dcdrnd[ 12]    6.300  109   31.173
set dcdrnd[ 13]    6.200  108   30.191
set dcdrnd[ 14]    6.100  107   29.225
set dcdrnd[ 15]    6.000  106   28.274
set dcdrnd[ 16]    5.900  105   27.340
set dcdrnd[ 17]    5.800  104   26.421
set dcdrnd[ 18]    5.700  103   25.518
set dcdrnd[ 19]    5.600  102   24.630
set dcdrnd[ 20]    5.500  101   23.758
set dcdrnd[ 21]    5.400  100   22.902
set dcdrnd[ 22]    5.300   99   22.062
set dcdrnd[ 23]    5.200   98   21.237
set dcdrnd[ 24]    5.100   97   20.428
set dcdrnd[ 25]    5.000   96   19.635
set dcdrnd[ 26]    4.900   95   18.857
set dcdrnd[ 27]    4.800   94   18.096
set dcdrnd[ 28]    4.700   93   17.349
set dcdrnd[ 29]    4.600   92   16.619
set dcdrnd[ 30]    4.500   91   15.904
set dcdrnd[ 31]    4.400   90   15.205
set dcdrnd[ 32]    4.300   89   14.522
set dcdrnd[ 33]    4.200   88   13.854
set dcdrnd[ 34]    4.100   87   13.203
set dcdrnd[ 35]    4.000   86   12.566
set dcdrnd[ 36]    3.900   85   11.946
set dcdrnd[ 37]    3.800   84   11.341
set dcdrnd[ 38]    3.700   83   10.752
set dcdrnd[ 39]    3.600   82   10.179
set dcdrnd[ 40]    3.500   81    9.621
set dcdrnd[ 41]    3.400   80    9.079
set dcdrnd[ 42]    3.300   79    8.553
set dcdrnd[ 43]    3.200   78    8.043
set dcdrnd[ 44]    3.100   77    7.548
set dcdrnd[ 45]    3.000   76    7.069
set dcdrnd[ 46]    2.900   75    6.605
set dcdrnd[ 47]    2.800   74    6.158
set dcdrnd[ 48]    2.700   73    5.726
set dcdrnd[ 49]    2.600   72    5.309
set dcdrnd[ 50]    2.500   71    4.909
set dcdrnd[ 51]    2.400   70    4.524
set dcdrnd[ 52]    2.300   69    4.155
set dcdrnd[ 53]    2.200   68    3.801
set dcdrnd[ 54]    2.100   67    3.464
set dcdrnd[ 55]    2.000   66    3.142
set dcdrnd[ 56]    1.900   65    2.835
set dcdrnd[ 57]    1.800   64    2.545
set dcdrnd[ 58]    1.700   63    2.270
set dcdrnd[ 59]    1.600   62    2.011
set dcdrnd[ 60]    1.500   61    1.767
set dcdrnd[ 61]    1.450   60    1.651
set dcdrnd[ 62]    1.400   59    1.539
set dcdrnd[ 63]    1.350   58    1.431
set dcdrnd[ 64]    1.300   57    1.327
set dcdrnd[ 65]    1.250   56    1.227
set dcdrnd[ 66]    1.200   55    1.131
set dcdrnd[ 67]    1.100   54    0.950
set dcdrnd[ 68]    1.000   53    0.785
set dcdrnd[ 69]    0.900   52    0.636
set dcdrnd[ 70]    0.800   51    0.503
set dcdrnd[ 71]    0.750   50    0.442
set dcdrnd[ 72]    0.700   49    0.385
set dcdrnd[ 73]    0.650   48    0.332
set dcdrnd[ 74]    0.600   47    0.283
set dcdrnd[ 75]    0.550   46    0.238
set dcdrnd[ 76]    0.500   45    0.196
set dcdrnd[ 77]    0.450   44    0.159
set dcdrnd[ 78]    0.400   43    0.126
set dcdrnd[ 79]    0.350   42    0.096
set dcdrnd[ 80]    0.320  124    0.080
set dcdrnd[ 81]    0.300   41    0.071
set dcdrnd[ 82]    0.250   40    0.049
set dcdrnd[ 83]    0.220   39    0.038
set dcdrnd[ 84]    0.200   38    0.031
set dcdrnd[ 85]    0.180   37    0.025
set dcdrnd[ 86]    0.150   36    0.018
set dcdrnd[ 87]    0.120  120    0.011
set dcdrnd[ 88]    0.100   35    0.008
set dcdrnd[ 89]    0.050  119    0.002
# �p�X���[�z�[��  �T�C�Y   D#     �ʐ�
set dcdrct[  0]    2.500   34    6.250
set dcdrct[  1]    2.400   33    5.760
set dcdrct[  2]    2.300   32    5.290
set dcdrct[  3]    2.200   31    4.840
set dcdrct[  4]    2.100   30    4.410
set dcdrct[  5]    2.000   29    4.000
set dcdrct[  6]    1.900   28    3.610
set dcdrct[  7]    1.800   27    3.240
set dcdrct[  8]    1.700   26    2.890
set dcdrct[  9]    1.600   25    2.560
set dcdrct[ 10]    1.500   24    2.250
set dcdrct[ 11]    1.400   23    1.960
set dcdrct[ 12]    1.300   22    1.690
set dcdrct[ 13]    1.200   21    1.440
set dcdrct[ 14]    1.000   19    1.000
set dcdrct[ 15]    0.900   20    0.810
# �T�[�}��        �T�C�Y   D#     �ʐ�
set dcdthr[  0]    1.900   18    0.000
set dcdthr[  1]    1.800   18    0.000
set dcdthr[  2]    1.700   18    0.000
set dcdthr[  3]    1.600   17    0.000
set dcdthr[  4]    1.500   17    0.000
set dcdthr[  5]    1.400   17    0.000
set dcdthr[  6]    1.300   16    0.000
set dcdthr[  7]    1.200   16    0.000
set dcdthr[  8]    1.100   15    0.000
set dcdthr[  9]    1.000   15    0.000
set dcdthr[ 10]    0.900   15    0.000
set dcdthr[ 11]    0.800   14    0.000
set dcdthr[ 12]    0.700   14    0.000
set dcdthr[ 13]    0.600   13    0.000
set dcdthr[ 14]    0.500   12    0.000
set dcdthr[ 15]    0.400   12    0.000
set dcdthr[ 16]    0.300   11    0.000
