// analyse.h : Headerdatei für die Konsolenanwendung zur Analyse des Digitalsignals.
// C 2005 Rainer Müller 
// Das Programm unterliegt den Bedingungen der GNU General Public License 3 (GPL3).

extern bool detail, mfxdetail; 

void analysiere(int start, int dauer);

